package com.hometail.web;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import java.time.LocalDate;

/**
 * A utility bean that provides date-related functionality throughout the application.
 * This bean is application-scoped, meaning a single instance is created and shared
 * across all users and requests in the application.
 * 
 * <p>This bean can be accessed from any JSF view using the expression <code>#{dateUtilsBean}</code>.</p>
 * 
 * <p><b>Example usage in JSF:</b></p>
 * <pre>
 * &lt;h:outputText value="Current date: #{dateUtilsBean.now}" /&gt;
 * </pre>
 * 
 * @see java.time.LocalDate
 */
@Named
@ApplicationScoped
public class DateUtilsBean {
    
    /**
     * Returns the current date using the system clock and default time-zone.
     * This method is useful for getting the current date in a consistent way
     * throughout the application, which can be helpful for testing and consistency.
     * 
     * @return the current date, not null
     */
    public LocalDate getNow() {
        return LocalDate.now();
    }
}
